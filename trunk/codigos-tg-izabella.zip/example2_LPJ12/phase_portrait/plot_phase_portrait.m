function plot_phase_portrait(x)

plot(x(:,1),x(:,2));
title ('Phase portrait' );
xlabel('x1'); ylabel ('x2');
%grid;
hold off

end

