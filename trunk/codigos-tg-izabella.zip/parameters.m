function [wf, V, Eref, m, n, Ro, Pref, Qref] = parameters()

wf = 2*pi*60;
V=311;
Eref=311;
m=3.77/22000;
n=20/22000;
Ro=0.1;
Pref=22000;
Qref=0;

end

